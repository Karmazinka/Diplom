package org.diplom.selenium;

import org.junit.jupiter.api.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ChromeTest {
    // ссылка для веб драйвера
    protected static WebDriver driver = null;

    // ссылки для элементов на сайте
    // кнопка Log in
    private final By btnLogin = By.xpath("//div[@class='logged-out']//a[@class='login']");
    // поле ввода email
    private final By inputEmail = By.xpath("//div[@class='creds']//input[@name='username']");
    // поле ввода пароля
    private final By inputPassword = By.xpath("//div[@class='creds']//input[@name='password']");
    // кнопка Join
    private final By btnJoin = By.xpath("//nav[@class='dropdown']//div[@class='login-button']");
    // кнопка профиля
    private final By btnProfile = By.xpath("//a[@class='avatar']");
    // сообщение об ошибке
    private final By errorTextEl = By.xpath("//nav[@class='dropdown']//div[@class='error']//div[@class='message']");

    /**
     * Настройка и создание драйвера браузера
     */
    public void settingBrowser() {
        System.setProperty("webdriver.chrome.driver", "src/resources/chrome/chromedriver.exe");
        driver = new ChromeDriver();
    }

    @Test
    @Order(1)
    public void negative() {
        try {
            settingBrowser();
            driver.get("https://imageshack.com/");
            driver.manage().window().maximize();

            // нажимаем кнопку Log In
            driver.findElement(btnLogin).click();
            try {
                // ждем отрисовку элементов
                Thread.sleep(250);
                // заполняем поля логина и пароля
                driver.findElement(inputEmail).sendKeys("fail_fail@mail.ru");
                driver.findElement(inputPassword).sendKeys("fail");
                // нажимаем кнопку логина
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            // нажимаем кнопку логина
            driver.findElement(btnJoin).click();
            // проверяем результат
            WebElement errorEl = driver.findElement(errorTextEl);
            Assertions.assertNotNull(errorEl);
        } finally {
            driver.close();
        }
    }

    @Test
    @Order(2)
    public void positive() {
        settingBrowser();
        try {
            driver.get("https://imageshack.com/");
            driver.manage().window().maximize();

            // нажимаем кнопку Log In
            driver.findElement(btnLogin).click();
            try {
                // ждем отрисовку элементов
                Thread.sleep(250);
                // заполняем поля логина и пароля
                driver.findElement(inputEmail).sendKeys("ula_romashkova@mail.ru");
                driver.findElement(inputPassword).sendKeys("ZYAuP3-hyra1");
                // нажимаем кнопку логина
                driver.findElement(btnJoin).click();
                Thread.sleep(1000);
                // рефрешим чтобы убрать баннер
                driver.navigate().refresh();
                Thread.sleep(1000);
                // проверяем кнопку пользователя на сайте
                WebElement profile = driver.findElement(btnProfile);
                // если она есть - мы залогинились
                Assertions.assertNotNull(profile);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        } finally {
            driver.close();
        }
    }
}

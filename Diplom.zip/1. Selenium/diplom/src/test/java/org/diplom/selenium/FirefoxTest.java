package org.diplom.selenium;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.TestMethodOrder;
//import org.openqa.selenium.firefox.GeckoDriver;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class FirefoxTest extends ChromeTest {

    public void settingBrowser () {
        System.setProperty("webdriver.gecko.driver", "src/resources/firefox/geckodriver.exe");
        //driver = new GeckoDriver();
    }
}

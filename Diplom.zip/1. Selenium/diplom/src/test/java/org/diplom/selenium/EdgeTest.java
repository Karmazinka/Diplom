package org.diplom.selenium;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.TestMethodOrder;
import org.openqa.selenium.edge.EdgeDriver;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class EdgeTest extends ChromeTest {

    public void settingBrowser () {
        System.setProperty("webdriver.edge.driver", "src/resources/edge/msedgedriver.exe");
        driver = new EdgeDriver();
    }
}

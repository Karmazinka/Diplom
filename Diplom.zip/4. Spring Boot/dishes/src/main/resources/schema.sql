drop table if exists products;

CREATE TABLE products
(
    product_id          int          NOT NULL AUTO_INCREMENT,
    name                varchar(250) NOT NULL,
    pfc_proteins        float,
    pfc_fats            float,
    pfc_carbohydrates   float,
    calories            int,
    PRIMARY KEY (product_id)
);

drop table if exists dishes;

CREATE TABLE dishes
(
    dish_id     int             NOT NULL AUTO_INCREMENT,
    name        varchar(250)    NOT NULL,
    PRIMARY KEY (dish_id)
);
INSERT INTO products (name, pfc_proteins, pfc_fats, pfc_carbohydrates, calories)
VALUES ('Молоко', 20, 5, 10, 300),
       ('Колбаса', 20, 30, 70, 900);

INSERT INTO dishes (name)
VALUES ('Оливье'),
       ('Макарошки');

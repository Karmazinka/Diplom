package org.diplom.dishes.controller;

import lombok.AllArgsConstructor;
import org.diplom.dishes.model.Cooking;
import org.diplom.dishes.service.CookingService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value = "/cooking", produces = MediaType.APPLICATION_JSON_VALUE)
@AllArgsConstructor
public class CookingController {

    /**
     * Сервис
     */
    private CookingService service;

    /**
     * Возвращает список всех
     */
    @GetMapping(value = "")
    public List<Cooking> findAll() {
        // вывод всех докторов
        return service.findAll();
    }

    /**
     * Возвращает по ID
     */
    @GetMapping(value = "/{id}")
    public Optional<Cooking> findById(@PathVariable Long id) {
        return service.findById(id);
    }

    /**
     * Сохраняет
     */
    @PostMapping(value = "")
    public Cooking save(@RequestBody Cooking entity) {
        return service.save(entity);
    }

    /**
     * Обновляет по ID или создает новое
     */
    @PutMapping(value = "/{id}")
    public Cooking update(@RequestBody Cooking entity,
                          @PathVariable Long id) {
        return service.findById(id).map(item -> {
            // обновляем данные
            item.setDishId(entity.getDishId());
            item.setProductId(entity.getProductId());
            item.setCount(entity.getCount());
            // сохраняем изменения
            return service.save(item);
            // если не нашли, сохраняем как новую
        }).orElseGet(() -> service.save(entity));
    }

    /**
     * Удаляет по ID
     */
    @DeleteMapping(value = "/{id}")
    public void deleteById(@PathVariable Long id) {
        service.deleteById(id);
    }
}

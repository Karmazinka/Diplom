package org.diplom.dishes.repository;

import org.diplom.dishes.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Декорируем интерфейс JPA для класса
 */
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
}
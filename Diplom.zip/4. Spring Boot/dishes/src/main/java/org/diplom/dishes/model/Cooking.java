package org.diplom.dishes.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@Table(name = "cooking")
/**
 * Модель приготовление
 */
public class Cooking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cooking_id")
    // поле id
    private Long id;
    // связь с блюдом
    @Column(name = "dish_id")
    private Long dishId;
    // связь с продуктом
    @Column(name = "product_id")
    private Long productId;
    // количетво
    private Double count;
}
package org.diplom.dishes.repository;

import org.diplom.dishes.model.Dish;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


/**
 * Декорируем интерфейс JPA для класса
 */
@Repository
public interface DishRepository extends JpaRepository<Dish, Long> {
}
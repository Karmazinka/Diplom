package org.diplom.dishes.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@Table(name = "products")
/**
 * Модель продукта
 */
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "product_id")
    // поле id
    private Long id;
    // наименование
    private String name;
    // белки
    @Column(name = "pfc_proteins")
    private Double pfcProteins;
    // жиры
    @Column(name = "pfc_fats")
    private Double pfcFats;
    // углеводы
    @Column(name = "pfc_carbohydrates")
    private Double pfcCarbohydrates;
    // калории
    private Long calories;
}

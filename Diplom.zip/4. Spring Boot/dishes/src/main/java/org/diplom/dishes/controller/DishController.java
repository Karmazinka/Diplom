package org.diplom.dishes.controller;

import lombok.AllArgsConstructor;
import org.diplom.dishes.model.Dish;
import org.diplom.dishes.service.DishService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value = "/dishes", produces = MediaType.APPLICATION_JSON_VALUE)
@AllArgsConstructor
public class DishController {

    /**
     * Сервис
     */
    private DishService service;

    /**
     * Возвращает список всех блюд
     */
    @GetMapping(value = "")
    public List<Dish> findAll() {
        // вывод всех
        return service.findAll();
    }

    /**
     * Возвращает блюдо по ID
     */
    @GetMapping(value = "/{id}")
    public Optional<Dish> findById(@PathVariable Long id) {
        return service.findById(id);
    }

    /**
     * Сохраняет блюдо
     */
    @PostMapping(value = "")
    public Dish save(@RequestBody Dish entity) {
        return service.save(entity);
    }

    /**
     * Обновляет блюдо по ID или создает новое
     */
    @PutMapping(value = "/{id}")
    public Dish update(@RequestBody Dish entity,
                          @PathVariable Long id) {
        return service.findById(id).map(item -> {
            // обновляем данные
            item.setName(entity.getName());
            // сохраняем изменения
            return service.save(item);
            // если не нашли, сохраняем как новую
        }).orElseGet(() -> service.save(entity));
    }

    /**
     * Удаляет блюдо по ID
     */
    @DeleteMapping(value = "/{id}")
    public void deleteById(@PathVariable Long id) {
        service.deleteById(id);
    }
}

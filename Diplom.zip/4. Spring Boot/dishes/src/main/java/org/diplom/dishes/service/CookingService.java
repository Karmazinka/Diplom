package org.diplom.dishes.service;

import lombok.AllArgsConstructor;
import org.diplom.dishes.model.Cooking;
import org.diplom.dishes.repository.CookingRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class CookingService {

    private CookingRepository repository;

    /**
     * Возвращает список всех элементов сущности
     */
    public List<Cooking> findAll() {
        return repository.findAll();
    }

    /**
     * Возвращает сущность по ID
     */
    public Optional<Cooking> findById(Long id) {
        return repository.findById(id);
    }

    /**
     * Создает сущность
     */
    public Cooking save(Cooking entity) {
        return repository.save(entity);
    }

    /**
     * Удаляет сущность по ID
     */
    public void deleteById(Long id) {
        repository.deleteById(id);
    }
}

package org.diplom.dishes.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@Table(name = "dishes")
/**
 * Модель блюда
 */
public class Dish {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "dish_id")
    // поле id
    private Long id;
    // поле наименования
    private String name;

}
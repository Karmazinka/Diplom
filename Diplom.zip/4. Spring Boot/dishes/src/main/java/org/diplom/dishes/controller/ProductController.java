package org.diplom.dishes.controller;

import lombok.AllArgsConstructor;
import org.diplom.dishes.model.Product;
import org.diplom.dishes.service.ProductService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value = "/products", produces = MediaType.APPLICATION_JSON_VALUE)
@AllArgsConstructor
public class ProductController {

    /**
     * Сервис
     */
    private ProductService service;

    /**
     * Возвращает список всех продуктов
     */
    @GetMapping(value = "")
    public List<Product> findAll() {
        // вывод всех пациентов
        return service.findAll();
    }

    /**
     * Возвращает продукт по ID
     */
    @GetMapping(value = "/{id}")
    public Optional<Product> findById(@PathVariable Long id) {
        return service.findById(id);
    }

    /**
     * Сохраняет продукт
     */
    @PostMapping(value = "")
    public Product save(@RequestBody Product patient) {
        return service.save(patient);
    }

    /**
     * Обновляет продукт по ID или создает новый
     */
    @PutMapping(value = "/{id}")
    public Product update(@RequestBody Product patient,
                          @PathVariable Long id) {
        return service.findById(id).map(item -> {
            // обновляем данные
            item.setName(patient.getName());
            item.setPfcFats(patient.getPfcFats());
            item.setPfcProteins(patient.getPfcProteins());
            item.setPfcCarbohydrates(patient.getPfcCarbohydrates());
            item.setCalories(patient.getCalories());
            // сохраняем изменения
            return service.save(item);
            // если не нашли, сохраняем как новую
        }).orElseGet(() -> service.save(patient));
    }

    /**
     * Удаляет продукт по ID
     */
    @DeleteMapping(value = "/{id}")
    public void deleteById(@PathVariable Long id) {
        service.deleteById(id);
    }
}

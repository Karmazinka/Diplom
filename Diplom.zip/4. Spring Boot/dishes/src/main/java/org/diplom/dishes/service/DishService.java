package org.diplom.dishes.service;

import lombok.AllArgsConstructor;
import org.diplom.dishes.model.Dish;
import org.diplom.dishes.repository.DishRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class DishService {

    private DishRepository repository;

    /**
     * Возвращает список всех элементов сущности
     */
    public List<Dish> findAll() {
        return repository.findAll();
    }

    /**
     * Возвращает сущность по ID
     */
    public Optional<Dish> findById(Long id) {
        return repository.findById(id);
    }

    /**
     * Создает сущность
     */
    public Dish save(Dish entity) {
        return repository.save(entity);
    }

    /**
     * Удаляет сущность по ID
     */
    public void deleteById(Long id) {
        repository.deleteById(id);
    }
}

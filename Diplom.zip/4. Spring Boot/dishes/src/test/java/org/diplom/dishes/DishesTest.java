package org.diplom.dishes;

import org.diplom.dishes.model.Dish;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class DishesTest extends BaseTest {

    /**
     * Вывод списка всех
     */
    @Test
    @Order(1)
    public void getAllDishes() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .get("/dishes")
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                // проверяем успешный ответ
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$", Matchers.hasSize(2)))
                // проверяем правильность ответа
                .andExpect(jsonPath("$[0].id", equalTo(1)))
                .andExpect(jsonPath("$[0].name", equalTo("Оливье")));
    }

    /**
     * Вывод по ID
     */
    @Test
    @Order(2)
    public void getDish() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .get("/dishes/2")
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                // проверяем успешный ответ
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isNotEmpty())
                // проверяем правильность ответа
                .andExpect(jsonPath("$.id", equalTo(2)))
                .andExpect(jsonPath("$.name", equalTo("Макарошки")));
    }

    /**
     * Создание нового
     */
    @Test
    @Order(3)
    public void createDish() throws Exception {
        // создаем экземпляр класса
        Dish entity = new Dish();
        // заполняем данные
        entity.setName("Блюдо дня 3");

        mockMvc.perform(MockMvcRequestBuilders
                        // путь к сущности
                        .post("/dishes")
                        // передаем в контенте созданный экземпляр
                        .content(asJsonString(entity))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                // проверяем успешный ответ
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isNotEmpty())
                // проверяем правильность ответа
                .andExpect(jsonPath("$.name", equalTo(entity.getName())));
    }

    /**
     * Обновление по ID
     */
    @Test
    @Order(4)
    public void updateDish() throws Exception {
        // создаем экземпляр класса
        Dish entity = new Dish();
        // заполняем данные
        entity.setName("Блюдо дня 2 - Новая версия");

        mockMvc.perform(MockMvcRequestBuilders
                        // путь к сущности
                        .put("/dishes/2")
                        // передаем в контенте созданный экземпляр
                        .content(asJsonString(entity))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                // проверяем успешный ответ
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isNotEmpty())
                // проверяем правильность ответа
                .andExpect(jsonPath("$.id", equalTo(2)))
                .andExpect(jsonPath("$.name", equalTo(entity.getName())));
    }

    /**
     * Удаление посещение по ID
     */
    @Test
    @Order(5)
    public void deleteDish() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        // путь к сущности
                        .delete("/dishes/1")
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                // проверяем успешный ответ
                .andExpect(status().isOk());
    }
}
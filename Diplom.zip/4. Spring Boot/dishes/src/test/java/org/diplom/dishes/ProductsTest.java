package org.diplom.dishes;

import org.diplom.dishes.model.Product;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ProductsTest extends BaseTest {

    /**
     * Вывод списка всех
     */
    @Test
    @Order(1)
    public void getAllProducts() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .get("/products")
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                // проверяем успешный ответ
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$", Matchers.hasSize(2)))
                // проверяем правильность ответа
                .andExpect(jsonPath("$[0].id", equalTo(1)))
                .andExpect(jsonPath("$[0].name", equalTo("Молоко")))
                .andExpect(jsonPath("$[0].pfcProteins", equalTo(20D)))
                .andExpect(jsonPath("$[0].pfcFats", equalTo(5D)))
                .andExpect(jsonPath("$[0].pfcCarbohydrates", equalTo(10D)))
                .andExpect(jsonPath("$[0].calories", equalTo(300)));
    }

    /**
     * Вывод по ID
     */
    @Test
    @Order(2)
    public void getProduct() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .get("/products/2")
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                // проверяем успешный ответ
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isNotEmpty())
                // проверяем правильность ответа
                .andExpect(jsonPath("$.id", equalTo(2)))
                .andExpect(jsonPath("$.name", equalTo("Колбаса")))
                .andExpect(jsonPath("$.pfcProteins", equalTo(20D)))
                .andExpect(jsonPath("$.pfcFats", equalTo(30D)))
                .andExpect(jsonPath("$.pfcCarbohydrates", equalTo(70D)))
                .andExpect(jsonPath("$.calories", equalTo(900)));
    }

    /**
     * Создание нового
     */
    @Test
    @Order(3)
    public void createProduct() throws Exception {
        // создаем экземпляр класса
        Product entity = new Product();
        // заполняем данные
        entity.setName("Тестовый продукт");
        entity.setPfcFats(5D);
        entity.setPfcCarbohydrates(20D);
        entity.setPfcProteins(60D);
        entity.setCalories(300L);

        mockMvc.perform(MockMvcRequestBuilders
                        // путь к сущности
                        .post("/products")
                        // передаем в контенте созданный экземпляр
                        .content(asJsonString(entity))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                // проверяем успешный ответ
                .andExpect(status().isOk())
                // тело ответа должно быть пустым
                .andExpect(jsonPath("$").isNotEmpty())
                // проверяем правильность ответа
                .andExpect(jsonPath("$.name", equalTo(entity.getName())))
                .andExpect(jsonPath("$.pfcProteins", equalTo(entity.getPfcProteins())))
                .andExpect(jsonPath("$.pfcFats", equalTo(entity.getPfcFats())))
                .andExpect(jsonPath("$.pfcCarbohydrates", equalTo(entity.getPfcCarbohydrates())))
                .andExpect(jsonPath("$.calories", equalTo(entity.getCalories().intValue())));
    }

    /**
     * Обновление по ID
     */
    @Test
    @Order(4)
    public void updateProduct() throws Exception {
        // создаем экземпляр класса
        Product entity = new Product();
        // заполняем данные
        entity.setName("Продукт 666");
        entity.setPfcFats(5D);
        entity.setPfcCarbohydrates(20D);
        entity.setPfcProteins(60D);
        entity.setCalories(300L);

        mockMvc.perform(MockMvcRequestBuilders
                        .put("/products/2")
                        // передаем в контенте созданный экземпляр
                        .content(asJsonString(entity))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                // проверяем успешный ответ
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isNotEmpty())
                // проверяем правильность ответа
                // проверяем ID
                .andExpect(jsonPath("$.id", equalTo(2)))
                // проверяем правильность ответа
                .andExpect(jsonPath("$.name", equalTo(entity.getName())))
                .andExpect(jsonPath("$.pfcProteins", equalTo(entity.getPfcProteins())))
                .andExpect(jsonPath("$.pfcFats", equalTo(entity.getPfcFats())))
                .andExpect(jsonPath("$.pfcCarbohydrates", equalTo(entity.getPfcCarbohydrates())))
                .andExpect(jsonPath("$.calories", equalTo(entity.getCalories().intValue())));
    }

    /**
     * Удаление по ID
     */
    @Test
    @Order(5)
    public void deleteDoctor() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        // путь к сущности
                        .delete("/products/1")
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                // проверяем успешный ответ
                .andExpect(status().isOk());
    }
}